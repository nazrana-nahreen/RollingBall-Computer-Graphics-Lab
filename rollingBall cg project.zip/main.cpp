/* =====================================================================
   ROLLING BALL 3D - a large open-area 3D rolling-ball game
   Computer Graphics Course Project
   Language : C++
   Library  : OpenGL + GLUT / freeglut
   IDE      : Code::Blocks

   The ball rolls physically (true rolling rotation) across a large
   checkered ground plane, dodging pillar obstacles and collecting
   spinning gold coins. The camera freely orbits around the ball so
   the whole scene can be viewed from any angle - behind, above,
   side-on, or close up.

   CONTROLS
   --------
   Keyboard :
        W / Up Arrow     -> roll forward   (camera-relative)
        S / Down Arrow   -> roll backward
        A / Left Arrow   -> roll left
        D / Right Arrow  -> roll right
        SPACE            -> jump
        R                -> restart
        ESC              -> quit

   Mouse :
        Left button + drag   -> orbit camera around the ball (any angle)
        Scroll wheel         -> zoom in / out
        (Right button + drag -> also orbit, for touchpads without a wheel)
   ===================================================================== */

#include <GL/glut.h>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>

/* --------------------------- constants --------------------------- */
const float PI = 3.14159265f;
const float BALL_RADIUS   = 1.0f;
const float GRAVITY       = -22.0f;
const float ACCEL         = 26.0f;
const float FRICTION      = 3.0f;     // ground damping
const float MAX_SPEED     = 14.0f;
const float JUMP_SPEED    = 9.0f;
const float WORLD_HALF    = 95.0f;    // ground extends -95..95
const float TILE_SIZE     = 10.0f;
const int   GAME_SECONDS  = 90;

/* --------------------------- structures --------------------------- */
struct Vec3 { float x, y, z; };

struct Obstacle {
    float x, z;      // center
    float halfW, halfD, height;
};

struct Coin {
    float x, z;
    bool  collected;
};

/* --------------------------- game state --------------------------- */
Vec3  ballPos = { 0, BALL_RADIUS, 0 };
Vec3  ballVel = { 0, 0, 0 };
bool  onGround = true;
GLfloat ballRotation[16] = {
    1,0,0,0,  0,1,0,0,  0,0,1,0,  0,0,0,1
};

bool keyW=false, keyS=false, keyA=false, keyD=false;

/* orbit camera */
float camYaw   = 0.4f;      // radians
float camPitch = 0.55f;     // radians (clamped)
float camDist  = 18.0f;
bool  leftDown = false, rightDown = false;
int   lastMouseX = 0, lastMouseY = 0;

int   winW = 1000, winH = 700;
int   score = 0;
int   startTimeMs = 0;
bool  gameWon = false, gameOver = false;

/* --------------------------- world content --------------------------- */
Obstacle obstacles[] = {
    { -30,  10, 2.5f, 2.5f, 6 },
    {  18, -22, 3.0f, 3.0f, 5 },
    {  45,  30, 2.0f, 2.0f, 8 },
    { -50, -40, 4.0f, 4.0f, 5 },
    {  60, -10, 2.5f, 2.5f, 6 },
    { -15,  55, 3.0f, 3.0f, 7 },
    {  5,   5,  2.0f, 2.0f, 4 },
    { -65,  20, 2.5f, 2.5f, 6 },
    {  30, -60, 3.5f, 3.5f, 6 },
    { -25, -65, 2.5f, 2.5f, 5 },
    {  70,  55, 3.0f, 3.0f, 7 },
    { -75, -5,  2.5f, 2.5f, 6 },
};
const int OBSTACLE_COUNT = sizeof(obstacles) / sizeof(Obstacle);

Coin coins[] = {
    { -20, 15, false }, { 20, -15, false }, { 35, 35, false },
    { -35, -35, false }, { 50, 0, false }, { -50, 0, false },
    { 0, 50, false }, { 0, -50, false }, { 60, 40, false },
    { -60, -40, false }, { 25, -50, false }, { -25, 50, false },
    { 70, -25, false }, { -70, 25, false }, { 10, 70, false },
    { -10, -70, false }, { 80, 10, false }, { -80, -10, false },
    { 40, -70, false }, { -40, 70, false },
};
const int COIN_COUNT = sizeof(coins) / sizeof(Coin);

/* --------------------------- small vector helpers --------------------------- */
float vlen(float x, float y) { return sqrtf(x*x + y*y); }

/* --------------------------- text helper --------------------------- */
void drawText(float x, float y, const char* text, void* font = GLUT_BITMAP_HELVETICA_18) {
    glRasterPos2f(x, y);
    for (const char* c = text; *c; c++) glutBitmapCharacter(font, *c);
}

/* --------------------------- drawing --------------------------- */
void drawGround() {
    glDisable(GL_LIGHTING); // flat, even coloring reads more clearly for a checkerboard
    int tiles = (int)((WORLD_HALF * 2) / TILE_SIZE);
    glBegin(GL_QUADS);
    for (int i = 0; i < tiles; i++) {
        for (int j = 0; j < tiles; j++) {
            float x0 = -WORLD_HALF + i * TILE_SIZE;
            float z0 = -WORLD_HALF + j * TILE_SIZE;
            bool light = ((i + j) % 2 == 0);
            if (light) glColor3f(0.35f, 0.70f, 0.32f);
            else       glColor3f(0.27f, 0.58f, 0.25f);
            glNormal3f(0, 1, 0);
            glVertex3f(x0,            0, z0);
            glVertex3f(x0 + TILE_SIZE,0, z0);
            glVertex3f(x0 + TILE_SIZE,0, z0 + TILE_SIZE);
            glVertex3f(x0,            0, z0 + TILE_SIZE);
        }
    }
    glEnd();
    glEnable(GL_LIGHTING);

    // low boundary wall so the play area edge reads clearly
    glColor3f(0.45f, 0.30f, 0.20f);
    float h = 3.0f;
    glBegin(GL_QUADS);
        // north / south walls
        glNormal3f(0,0,-1); glVertex3f(-WORLD_HALF,0,-WORLD_HALF); glVertex3f(WORLD_HALF,0,-WORLD_HALF); glVertex3f(WORLD_HALF,h,-WORLD_HALF); glVertex3f(-WORLD_HALF,h,-WORLD_HALF);
        glNormal3f(0,0, 1); glVertex3f(-WORLD_HALF,0, WORLD_HALF); glVertex3f(WORLD_HALF,0, WORLD_HALF); glVertex3f(WORLD_HALF,h, WORLD_HALF); glVertex3f(-WORLD_HALF,h, WORLD_HALF);
        // east / west walls
        glNormal3f(-1,0,0); glVertex3f(-WORLD_HALF,0,-WORLD_HALF); glVertex3f(-WORLD_HALF,0, WORLD_HALF); glVertex3f(-WORLD_HALF,h, WORLD_HALF); glVertex3f(-WORLD_HALF,h,-WORLD_HALF);
        glNormal3f( 1,0,0); glVertex3f( WORLD_HALF,0,-WORLD_HALF); glVertex3f( WORLD_HALF,0, WORLD_HALF); glVertex3f( WORLD_HALF,h, WORLD_HALF); glVertex3f( WORLD_HALF,h,-WORLD_HALF);
    glEnd();
}

void drawObstacles() {
    glColor3f(0.55f, 0.42f, 0.30f);
    for (int i = 0; i < OBSTACLE_COUNT; i++) {
        Obstacle &o = obstacles[i];
        glPushMatrix();
        glTranslatef(o.x, o.height * 0.5f, o.z);
        glScalef(o.halfW * 2, o.height, o.halfD * 2);
        glutSolidCube(1.0);
        glPopMatrix();
    }
}

void drawCoins(float timeSec) {
    glColor3f(1.0f, 0.84f, 0.0f);
    for (int i = 0; i < COIN_COUNT; i++) {
        if (coins[i].collected) continue;
        glPushMatrix();
        float bob = sinf(timeSec * 3.0f + i) * 0.15f;
        glTranslatef(coins[i].x, 1.2f + bob, coins[i].z);
        glRotatef(timeSec * 90.0f, 0, 1, 0);
        glScalef(1.0f, 1.0f, 0.25f);
        glutSolidSphere(0.6, 16, 16);
        glPopMatrix();
    }
}

void drawBall() {
    glColor3f(0.85f, 0.15f, 0.15f);
    glPushMatrix();
    glTranslatef(ballPos.x, ballPos.y, ballPos.z);
    glMultMatrixf(ballRotation);
    glutSolidSphere(BALL_RADIUS, 32, 32);
    glPopMatrix();
}

/* --------------------------- camera --------------------------- */
void applyCamera() {
    float cp = cosf(camPitch), sp = sinf(camPitch);
    float cy = cosf(camYaw),   sy = sinf(camYaw);

    float offX = camDist * cp * sy;
    float offY = camDist * sp;
    float offZ = camDist * cp * cy;

    Vec3 eye = { ballPos.x + offX, ballPos.y + offY + 1.5f, ballPos.z + offZ };
    gluLookAt(eye.x, eye.y, eye.z,
              ballPos.x, ballPos.y + 1.0f, ballPos.z,
              0, 1, 0);
}

/* --------------------------- HUD (2D overlay) --------------------------- */
void drawHUD() {
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0, winW, 0, winH);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();

    glDisable(GL_LIGHTING);
    glDisable(GL_DEPTH_TEST);

    char buf[64];
    glColor3f(1, 1, 1);
    sprintf(buf, "Coins: %d / %d", score, COIN_COUNT);
    drawText(15, winH - 25, buf);

    int elapsed = (glutGet(GLUT_ELAPSED_TIME) - startTimeMs) / 1000;
    int remaining = GAME_SECONDS - elapsed;
    if (remaining < 0) remaining = 0;
    sprintf(buf, "Time: %02d", remaining);
    drawText(winW - 100, winH - 25, buf);

    drawText(15, winH - 48,
        "WASD/Arrows: roll   Space: jump   Mouse-drag: orbit view   Wheel: zoom   R: restart",
        GLUT_BITMAP_HELVETICA_12);

    if (gameWon) {
        glColor3f(0.6f, 1.0f, 0.6f);
        drawText(winW/2 - 100, winH/2, "ALL COINS COLLECTED! Press R", GLUT_BITMAP_HELVETICA_18);
    } else if (gameOver) {
        glColor3f(1.0f, 0.5f, 0.5f);
        drawText(winW/2 - 90, winH/2, "TIME UP! Press R to restart", GLUT_BITMAP_HELVETICA_18);
    }

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);

    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
}

/* --------------------------- display --------------------------- */
void display() {
    glClearColor(0.55f, 0.78f, 0.95f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    applyCamera();

    GLfloat lightPos[] = { 40.0f, 80.0f, 40.0f, 1.0f };
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos);

    drawGround();
    drawObstacles();
    drawCoins(glutGet(GLUT_ELAPSED_TIME) / 1000.0f);
    drawBall();

    drawHUD();
    glutSwapBuffers();
}

/* --------------------------- collision --------------------------- */
void resolveObstacleCollisions() {
    for (int i = 0; i < OBSTACLE_COUNT; i++) {
        Obstacle &o = obstacles[i];
        float minX = o.x - o.halfW - BALL_RADIUS, maxX = o.x + o.halfW + BALL_RADIUS;
        float minZ = o.z - o.halfD - BALL_RADIUS, maxZ = o.z + o.halfD + BALL_RADIUS;
        if (ballPos.x > minX && ballPos.x < maxX && ballPos.z > minZ && ballPos.z < maxZ &&
            ballPos.y < o.height + BALL_RADIUS) {
            // push out along the axis of least penetration
            float pushLeft  = ballPos.x - minX;
            float pushRight = maxX - ballPos.x;
            float pushDown  = ballPos.z - minZ;
            float pushUp    = maxZ - ballPos.z;
            float m = pushLeft;
            char axis = 'L';
            if (pushRight < m) { m = pushRight; axis = 'R'; }
            if (pushDown  < m) { m = pushDown;  axis = 'D'; }
            if (pushUp    < m) { m = pushUp;    axis = 'U'; }

            if (axis == 'L') { ballPos.x = minX; ballVel.x = 0; }
            if (axis == 'R') { ballPos.x = maxX; ballVel.x = 0; }
            if (axis == 'D') { ballPos.z = minZ; ballVel.z = 0; }
            if (axis == 'U') { ballPos.z = maxZ; ballVel.z = 0; }
        }
    }
}

void resolveCoinPickups() {
    for (int i = 0; i < COIN_COUNT; i++) {
        if (coins[i].collected) continue;
        float dx = ballPos.x - coins[i].x;
        float dz = ballPos.z - coins[i].z;
        if (vlen(dx, dz) < BALL_RADIUS + 0.8f) {
            coins[i].collected = true;
            score++;
            if (score == COIN_COUNT) gameWon = true;
        }
    }
}

/* --------------------------- physics --------------------------- */
void updateBallRotation(float dx, float dz) {
    float dist = vlen(dx, dz);
    if (dist < 1e-5f) return;
    float axisX = -dz / dist;
    float axisZ =  dx / dist;
    float angleDeg = (dist / BALL_RADIUS) * (180.0f / PI);

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    glRotatef(angleDeg, axisX, 0, axisZ);
    glMultMatrixf(ballRotation);
    glGetFloatv(GL_MODELVIEW_MATRIX, ballRotation);
    glPopMatrix();
}

void updatePhysics(float dt) {
    if (gameWon || gameOver) return;

    // camera-relative input directions
    float fx = -sinf(camYaw), fz = -cosf(camYaw);   // forward
    float rx =  cosf(camYaw), rz = -sinf(camYaw);   // right

    float ax = 0, az = 0;
    if (keyW) { ax += fx; az += fz; }
    if (keyS) { ax -= fx; az -= fz; }
    if (keyD) { ax += rx; az += rz; }
    if (keyA) { ax -= rx; az -= rz; }

    float alen = vlen(ax, az);
    if (alen > 1e-5f) { ax /= alen; az /= alen; }

    ballVel.x += ax * ACCEL * dt;
    ballVel.z += az * ACCEL * dt;

    // friction (only meaningful component on ground plane)
    float speed = vlen(ballVel.x, ballVel.z);
    if (speed > 0) {
        float drop = FRICTION * dt;
        float newSpeed = speed - drop;
        if (newSpeed < 0) newSpeed = 0;
        float scale = (speed > 1e-5f) ? (newSpeed / speed) : 0;
        ballVel.x *= scale;
        ballVel.z *= scale;
    }
    speed = vlen(ballVel.x, ballVel.z);
    if (speed > MAX_SPEED) {
        float scale = MAX_SPEED / speed;
        ballVel.x *= scale;
        ballVel.z *= scale;
    }

    // gravity + vertical motion
    ballVel.y += GRAVITY * dt;
    ballPos.y += ballVel.y * dt;
    if (ballPos.y <= BALL_RADIUS) {
        ballPos.y = BALL_RADIUS;
        ballVel.y = 0;
        onGround = true;
    } else {
        onGround = false;
    }

    float dx = ballVel.x * dt;
    float dz = ballVel.z * dt;
    ballPos.x += dx;
    ballPos.z += dz;

    // world boundary clamp
    float lim = WORLD_HALF - BALL_RADIUS;
    if (ballPos.x >  lim) { ballPos.x =  lim; ballVel.x = 0; }
    if (ballPos.x < -lim) { ballPos.x = -lim; ballVel.x = 0; }
    if (ballPos.z >  lim) { ballPos.z =  lim; ballVel.z = 0; }
    if (ballPos.z < -lim) { ballPos.z = -lim; ballVel.z = 0; }

    resolveObstacleCollisions();
    resolveCoinPickups();
    updateBallRotation(dx, dz);

    int elapsed = (glutGet(GLUT_ELAPSED_TIME) - startTimeMs) / 1000;
    if (elapsed >= GAME_SECONDS && !gameWon) gameOver = true;
}

void timerFunc(int value) {
    updatePhysics(1.0f / 60.0f);
    glutPostRedisplay();
    glutTimerFunc(16, timerFunc, 0);
}

/* --------------------------- game control --------------------------- */
void resetGame() {
    ballPos = { 0, BALL_RADIUS, 0 };
    ballVel = { 0, 0, 0 };
    onGround = true;
    score = 0;
    gameWon = false;
    gameOver = false;
    startTimeMs = glutGet(GLUT_ELAPSED_TIME);
    for (int i = 0; i < COIN_COUNT; i++) coins[i].collected = false;

    GLfloat identity[16] = { 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1 };
    memcpy(ballRotation, identity, sizeof(identity));

    camYaw = 0.4f; camPitch = 0.55f; camDist = 18.0f;
}

/* --------------------------- input --------------------------- */
void keyDown(unsigned char key, int, int) {
    switch (key) {
        case 'w': case 'W': keyW = true; break;
        case 's': case 'S': keyS = true; break;
        case 'a': case 'A': keyA = true; break;
        case 'd': case 'D': keyD = true; break;
        case ' ': if (onGround) { ballVel.y = JUMP_SPEED; onGround = false; } break;
        case 'r': case 'R': resetGame(); break;
        case 27: exit(0);
    }
}
void keyUp(unsigned char key, int, int) {
    switch (key) {
        case 'w': case 'W': keyW = false; break;
        case 's': case 'S': keyS = false; break;
        case 'a': case 'A': keyA = false; break;
        case 'd': case 'D': keyD = false; break;
    }
}
void specialDown(int key, int, int) {
    switch (key) {
        case GLUT_KEY_UP:    keyW = true; break;
        case GLUT_KEY_DOWN:  keyS = true; break;
        case GLUT_KEY_LEFT:  keyA = true; break;
        case GLUT_KEY_RIGHT: keyD = true; break;
    }
}
void specialUp(int key, int, int) {
    switch (key) {
        case GLUT_KEY_UP:    keyW = false; break;
        case GLUT_KEY_DOWN:  keyS = false; break;
        case GLUT_KEY_LEFT:  keyA = false; break;
        case GLUT_KEY_RIGHT: keyD = false; break;
    }
}

void mouseButton(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON) {
        leftDown = (state == GLUT_DOWN);
        lastMouseX = x; lastMouseY = y;
    }
    if (button == GLUT_RIGHT_BUTTON) {
        rightDown = (state == GLUT_DOWN);
        lastMouseX = x; lastMouseY = y;
    }
    // scroll wheel: button 3 = up, button 4 = down (GLUT convention)
    if (state == GLUT_DOWN && button == 3) { camDist -= 1.5f; if (camDist < 5) camDist = 5; }
    if (state == GLUT_DOWN && button == 4) { camDist += 1.5f; if (camDist > 60) camDist = 60; }
}

void mouseMotion(int x, int y) {
    if (leftDown || rightDown) {
        int dx = x - lastMouseX;
        int dy = y - lastMouseY;
        camYaw   -= dx * 0.005f;
        camPitch += dy * 0.005f;
        if (camPitch > 1.45f) camPitch = 1.45f;   // avoid flipping over the top
        if (camPitch < -0.30f) camPitch = -0.30f; // avoid going under the ground
        lastMouseX = x; lastMouseY = y;
    }
}

/* --------------------------- window setup --------------------------- */
void reshape(int w, int h) {
    winW = w; winH = h;
    if (h == 0) h = 1;
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0, (double)w / h, 0.1, 500.0);
    glMatrixMode(GL_MODELVIEW);
}

void initGL() {
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_COLOR_MATERIAL);
    glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
    glEnable(GL_NORMALIZE);

    GLfloat ambient[] = { 0.35f, 0.35f, 0.35f, 1.0f };
    GLfloat diffuse[] = { 0.9f, 0.9f, 0.85f, 1.0f };
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);

    glClearColor(0.55f, 0.78f, 0.95f, 1.0f);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(winW, winH);
    glutInitWindowPosition(80, 40);
    glutCreateWindow("Rolling Ball 3D - CG Course Project");

    initGL();
    resetGame();

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyDown);
    glutKeyboardUpFunc(keyUp);
    glutSpecialFunc(specialDown);
    glutSpecialUpFunc(specialUp);
    glutMouseFunc(mouseButton);
    glutMotionFunc(mouseMotion);
    glutTimerFunc(0, timerFunc, 0);

    glutMainLoop();
    return 0;
}
